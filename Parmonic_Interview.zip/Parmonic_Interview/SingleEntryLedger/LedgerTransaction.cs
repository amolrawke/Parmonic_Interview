﻿using System;

namespace SingleEntryLedger
{
    internal class LedgerTransaction
    {
        public int Id { get; private set; }
        public string LedgerAccountId { get; private set; }
        public string TransactionId { get; private set; }
        public string EntryDescription { get; private set; }
        public DateTime? ReconciledOn { get; private set; }
        public TransactionAmount TransactionAmount { get; private set; } 
        private LedgerTransaction(int id, TransactionAmount transactionAmount,
            string transactionId,
            string entryDescription,
            string batchId,
            string ledgerAccountId)
        {
           
        }

        internal static IResult<LedgerTransaction> CreateTransaction()
        {
           
            return  null;
        }
    }

    public class TransactionAmount
    {
    }
}