﻿namespace SingleEntryLedger
{
    public interface IResult<T>
    {
    }
}