﻿namespace SingleEntryLedger
{
    internal class CashTransaction
    {
    }
}