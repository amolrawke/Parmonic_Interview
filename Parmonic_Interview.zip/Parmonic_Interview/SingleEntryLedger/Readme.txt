﻿DDD approach Single Ledger System

Create Ledger class as agreegate root
LedgerTransaction to maintain daily Accounting Transactions