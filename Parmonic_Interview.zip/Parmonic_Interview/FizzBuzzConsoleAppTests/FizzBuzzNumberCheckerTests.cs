﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzzConsoleApp;
using System;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzzConsoleApp.Tests
{
    [TestClass()]
    public class FizzBuzzNumberCheckerTests
    {
        FizzBuzzNumberChecker checker = new FizzBuzzNumberChecker();

        [TestMethod()]
        public void FizzBuzzNumberTest()
        {
            string text = string.Empty;
            text = checker.FizzBuzzNumber(3);
            Assert.AreEqual(text, "Fizz");
            text = checker.FizzBuzzNumber(5);
            Assert.AreEqual(text, "Buzz");
            text = checker.FizzBuzzNumber(15);
            Assert.AreEqual(text, "FizzBuzz");
            text = checker.FizzBuzzNumber(2);
            Assert.AreEqual(text, "2");

        }
    }
}