﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RateLimiter
{
    [Route("rates")]
    [ApiController]
    public class RatesController : ControllerBase
    {
        [HttpGet("getAllRates")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IEnumerable<Rates> GateRates()
        {
            return GetRateDetail();
        }

        private List<Rates> GetRateDetail()
        {

            return new List<Rates>()
            {
                new Rates()
                {
                Id = 1,
                Name= "Test"

                },
                 new Rates()
                {
                Id = 2,
                Name= "Test2"

                }

            };
        }
    }
}
