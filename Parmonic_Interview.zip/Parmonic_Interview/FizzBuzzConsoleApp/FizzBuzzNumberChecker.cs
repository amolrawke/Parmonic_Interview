﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzzConsoleApp
{
    public  class FizzBuzzNumberChecker
    {        
        public string FizzBuzzNumber(int number)
        {
            string strValue = string.Empty;
            try
            {
                if (number % 15 == 0)
                {
                    strValue = "FizzBuzz";
                }
                else if (number % 3 == 0)
                {

                    strValue = "Fizz";
                }
                else if (number % 5 == 0)
                {

                    strValue = "Buzz";
                }
                else
                {

                    strValue = Convert.ToString(number);
                }
                Console.WriteLine(strValue);
            }
            catch(Exception oex)
            {
                Console.WriteLine(oex);
            }
            return strValue;
        }
    }
}
