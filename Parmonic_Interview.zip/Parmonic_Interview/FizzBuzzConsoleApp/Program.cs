﻿using System;

namespace FizzBuzzConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            FizzBuzzNumberChecker checker = new FizzBuzzNumberChecker();
            checker.FizzBuzzNumber(3);
        }
    }
}
